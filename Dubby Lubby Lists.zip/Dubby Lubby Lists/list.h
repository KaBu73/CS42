#ifndef CS20A_LIST_H
#define CS20A_LIST_H

#include<iostream>
#include<assert.h>
using namespace std;
// Linked List object that maintains both m_head and m_tail pointers
// and the m_size of the list.  Note that you have to keep the m_head,
// m_tail and m_size consistent with the intended state of the List 
// otherwise very bad things happen. 
template<typename Item>
class List {
public:
	List();
	List(const List<Item>& other);
	List<Item>& operator=(const List<Item>& other);
	~List();

	void	print() const;
	bool	empty() const;

	void	push_front(const Item &item);
	void	push_rear(const Item &item);
	void	insert(int index, const Item &item);

	// Note that the user must first ensure the list is not empty
	// prior to calling these functions.
	Item	front() const;
	Item	rear() const;
	Item	get(int index) const;

	int		size() const;
	int		find(const Item &item) const;

	bool	pop_front();
	bool	pop_rear();
	bool	remove(int index);

#ifndef MAKE_MEMBERS_PUBLIC
private:
#endif
	// Forward declare the nodes for our List.
	// Will be implemented along with list's
	// member functions
	class Node;

	// We'll have both m_head and m_tail points for 
	// Fast insertion/deletion from both ends.
	Node*	m_head;
	Node*	m_tail;

	// Keep track of number of nodes in the list
	int		m_size;
};


/* List Implementation
//
//  Since List is a template class (which is not an actual
//  class yet, not until we actually instantiate the list)
//  we need to keep the implementation together with
//  the definition.  There are ways to simulate having
//  separate "implementation/definition" with templates,
//  but they aren't necessary and can be confusing.
*/

/* Node definition
//		Already implemented, nothing to do here but to use it.
*/
template<typename Item>
struct List<Item>::Node {
	Node() :next(nullptr), prev(nullptr) {}
	Node(Item it, Node* p, Node* n) : item(it), next(n), prev(p) {}

	Item  item;
	Node* next;
	Node* prev;
};

/* List default constructor
//		Set m_head and m_tail pointer to point to nothing, m_size is zero
//		Already implemented, nothing to do.
*/
template<typename Item>
List<Item>::List() :m_head(nullptr), m_tail(nullptr), m_size(0) {
}


/* Copy constructor                                                    
*/
template<typename Item>
List<Item>::List(const List<Item>& other) {
	Node* temp = other.m_head;
	for (int i = 1; i < other.m_size; i++) {
		push_rear(temp->item);
		temp = temp->next;
	}
}
/* Overloaded assignment operator                                  
*/
template<typename Item>
List<Item>& List<Item>::operator=(const List<Item>& other) {
	if (this == &other)
		return *this;

	Node* temp;
	temp = m_head;
	Node* p;
	while (temp != nullptr) {
		p = temp->next;
		delete temp;
		temp = p;
	}

	Node* temp = other.m_head;
	for (int i = 1; i < other.m_size; i++) {
		push_rear(temp->item);
		temp = temp->next;

	}
}


/* List destructor
*/
template<typename Item>
List<Item>::~List() {
	Node* temp;
	temp = m_head;
	Node* p;
	while (temp != nullptr) {
		p = temp->next;
		delete temp;
		temp = p;
	}
}

/* List print
*/
template<typename Item>
void List<Item>::print() const {
	if (m_head == nullptr || m_tail == nullptr)
		return;
	Node* temp;
	temp = m_head;
	while (temp != nullptr) {
		cout << temp->item;
		if (temp != m_tail)
			cout << " ";
		temp = temp->next;
	}
	cout << endl;
}

/* List empty
*/
template<typename Item>
bool List<Item>::empty() const {
	if (m_size == 0 && m_head == nullptr && m_tail == nullptr)
		return true;
	return false;
}


/* List push_front
*/
template<typename Item>
void List<Item>::push_front(const Item &item) {
	Node* temp;
	temp = new Node;
	temp->item = item;

	if (m_head != nullptr)
		m_head->prev = temp;
	temp->next = m_head;
	temp->prev = nullptr;
	m_head = temp;
	if (m_tail == nullptr)
		m_tail = temp;
	m_size++;
}

/* List push_rear
*/
template<typename Item>
void List<Item>::push_rear(const Item &item) {
	if (m_head == nullptr)
		push_front(item);
	else {
		Node* p;
		p = new Node;
		p->item = item;
		m_tail->next = p;
		p->prev = m_tail;
		p->next = nullptr;
		m_tail = p;
		m_size++;
	}
}

/* List insert
*/
template<typename Item>
void List<Item>::insert(int index, const Item &item) {
	if (index <= 0) {
		push_front(item);
		return;
	}
	if (index > m_size) {
		push_rear(item);
		return;
	}
	Node* temp;
	temp = m_head;
	for (int i = 1; i < index; i++)   //loop to get to node previous to the node at the index
		temp = temp->next;
	Node* p;
	p = new Node;
	p->item = item;
	p->next = temp->next;
	p->prev = temp;
	temp->next = p;
	temp = p->next;
	temp->prev = p;
	m_size++;
}

/*  List front
*/
template<typename Item>
Item List<Item>::front() const {
	assert(m_head != nullptr);
	return m_head->item;
}

/* List rear
*/
template<typename Item>
Item List<Item>::rear() const {
	assert(m_tail != nullptr);
	return m_tail->item;

}

/* List get
//		returns the item at index
*/
template<typename Item>
Item List<Item>::get(int index) const {
	assert(index >= 0 && index < m_size);

	Node* temp;
	temp = m_head;
	for (int i = 0; i < index; i++)
		temp = temp->next;

	return temp->item;
}

/* List size
*/
template<typename Item>
int List<Item>::size() const {
	return m_size;
}

/* List find
*/
template<typename Item>
int List<Item>::find(const Item &item) const {
	Node* temp;
	temp = m_head;
	for (int i = 0; i < m_size; i++) {
		if (temp->item == item)
			return i;
		temp = temp->next;
	}
	return -1;
}

/* List pop_front
*/
template<typename Item>
bool List<Item>::pop_front() {
	if (m_head == nullptr)
		return false;
	Node* destroy = m_head;
	m_head = destroy->next;
	m_head->prev = nullptr;
	delete destroy;
	m_size--;
	return true;
}

/* List pop_rear
*/
template<typename Item>
bool List<Item>::pop_rear() {
	if (m_tail == nullptr)
		return false;
	Node* destroy = m_tail;
	m_tail = m_tail->prev;
	m_tail->next = nullptr;
	delete destroy;
	m_size--;
	return true;
}

/* List remove
*/
template<typename Item>
bool List<Item>::remove(int index) {
	if (m_head == nullptr || index >= m_size || index < 0)
		return false;
	if (index = 0)
		pop_front();
	if (index = (m_size-1))
		pop_rear();
	Node* destroy;
	destroy = m_head;
	for (int i = 0; i < index; i++)   //loop to get to node previous to the node at the index
		destroy = destroy->next;
	destroy->prev->next = destroy->next;
	destroy->next->prev = destroy->prev;
	delete destroy;
	m_size--;
	return true;
}







































































#endif // _X_XMMXX