#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

namespace StudentInfo {
	std::string name() { return "Karan Buxey"; }
	std::string id() { return "1722374"; }
};

#endif