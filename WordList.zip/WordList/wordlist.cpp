/* WordList source file
*	Topics: Multilevel Pointers, Dynamic Allocation, Classes
*/
#ifdef _MSC_VER  //  Microsoft Visual C++

#define _CRT_SECURE_NO_DEPRECATE

#else  // not Microsoft Visual C++, so assume UNIX interface

#endif



// Do not include any other libraries
#include"wordlist.h"
#include<iostream>
#include<cstring>

using std::cout;
using std::endl;

using std::strcat;
using std::strcmp;
using std::strcpy;
using std::strlen;

/* Function: Wordlist Constructor
*/
WordList::WordList(const int max_words) {
	if (max_words < 1) {
		m_list = nullptr;
		m_count = 0;
		m_max = 0;
	}
	else {
		m_count = 0;
		m_max = max_words;
		m_list = new char*[m_max];
		for (int i = 0; i < m_max; ++i) {
			m_list[i] = new char[20];
			m_list[i][0] = '\0';
		}
	}

}

/* Function: Wordlist Copy Constructor
*/
WordList::WordList(const WordList &other) {
	m_count = other.m_count;
	m_max = other.m_max;
	m_list = new char*[m_max];	
	for (int i = 0; i < m_max; ++i)
		m_list[i] = other.m_list[i];
}


/* Function: Wordlist Destructor
*/
WordList::~WordList() {
	for (int i = 0; i < m_max; ++i) {
		delete[] m_list[i];
	}
	delete[] m_list;
}

/* Function: printList
*/
int	WordList::print() const {
	if (m_list == nullptr)
		return -1;
	else {
		for (int i = 0; i < m_count; i++) {
			cout << m_list[i];
			if(i < (m_count-1)) 
				cout << " ";
		} 
		cout << endl;
		return m_count;
	}
	
}

/* Function: at
*/
char* WordList::at(const int index) const {
	if(index > m_max || index < 0)
		return nullptr;
	else {
		char* word = m_list[index];
		return word;
	}
}


/* Function: count
*/
int	WordList::count() const {
	if (m_list == nullptr)
		return -1;
	else
		return m_count;
}


/* Function: add
*/
int	WordList::add(const char word[]) {
	if(m_list == nullptr)
		return -2;
	if (m_count <= m_max) {
		for (int i = 0; i < m_max; i++) {
			if (m_list[i][0] == '\0') {
				strcpy(m_list[i], word);
				m_count++;
				return 0;
			}
		}
	}
	else if (m_count > m_max) {
		m_max++;

		char** t_list = new char*[m_max];
		for (int i = 0; i < m_max; i++) {
			t_list[i] = new char[20];
			strcpy(t_list[i], m_list[i]);
		}

		for (int i = 0; i < m_max; i++) {
			delete[] m_list[i];
		}
		delete[] m_list;

		strcpy(t_list[m_max - 1], word);

		m_list = t_list;

		m_count++;
	}
}


/* Funtion: remove
*/
int	WordList::remove(const char word[]) {
	if(m_list == nullptr)
		return -1;
	bool repeats = true; 
	int count = 0;
	do {
		int s = search(word);
		if (s != -1) {
			for (int i = s; i < (m_max - 1); i++) {
				m_list[i] = m_list[i + 1];
			}
			count++;
		}
		if (s == -1)
			repeats = false;
	} while (repeats == true);
	return count;
}

/* Funtion: append
*/
int	WordList::append(const WordList* other) {
	m_count = m_count + other->m_count;
	if (m_list == nullptr)
		return -1;
	if (m_count > m_max)
		m_max = m_count;
	strcat(*m_list, *other->m_list);
	return other->m_count;

}


/* Funtion: search
*/
int WordList::search(const char word[]) const {

	for (int i = 0; i < m_max; i++) {
		if (strcmp(m_list[i], word) == 0) {
			return i;
		}
	}
	if (m_list == nullptr)
		return -1;
	return -1;

}


/* Funtion: sort
*/
int	WordList::sort() {
	if (m_list == nullptr)
		return -1;
	if (m_count == 1)
		return 1;
	for (int i = 0; i < m_max; i++) {
		for (int j = 1; j < (m_max - i); j++) {
			if (strcmp(m_list[j - 1], m_list[j]) > 0) {
				char* temp = m_list[j - 1];
				m_list[j - 1] = m_list[j];
				m_list[j] = temp;
			}
		}
	}
	return 0;

}

/*
Funtion: Assignment Operator
*/
WordList& WordList::operator=(const WordList &other) {

	if (this == &other)
		return *this;

	for (int i = 0; i < m_max; i++) {
		delete[] m_list[i];
	}
	delete[] m_list;

	m_count = other.m_count;
	m_max = other.m_max;
	char** m_list = new char*[m_max];
	for (int i = 0; i < m_max; i++)
		m_list[i] = other.m_list[i];

	return *this;
}
